var app = angular.module("app", []);

app.controller("PruebaController", ['$scope',function($scope) {


}]);