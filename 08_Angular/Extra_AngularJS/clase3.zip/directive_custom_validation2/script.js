// Code goes here

myApp = angular.module("myApp", []);
    
myApp.controller("searchCtrl", function($scope){
  
  // This is to hold the validation until we submit the form.
  $scope.submitSearch = function(){
    if($scope.searchForm.$valid) {
      console.log("form sent");
    }else{
      // If form is invalid, show errors
      $scope.searchForm.submitted = true;
    }
  }
  
  // This is to reset the search model and all errors from screen.
  $scope.reset = function(){
    $scope.search = {}
    $scope.searchForm.submitted = false;
  }

});

myApp.directive("myValidateAirportCode", function(){
  // requires an isloated model
  return {
   // restrict to an attribute type.
   restrict: 'A',
  // element must have ng-model attribute.
   require: 'ngModel', 
   link: function(scope, ele, attrs, ctrl){

      // add a parser that will process each time the value is 
      // parsed into the model when the user updates it.
      ctrl.$parsers.unshift(function(value) {
        if(value){
          // test and set the validity after update.
          var valid = value.charAt(0) == 'A' || value.charAt(0) == 'a';
          ctrl.$setValidity('invalidAiportCode', valid);
        }
          
        // if it's valid, return the value to the model, 
        // otherwise return undefined.
        return valid ? value : undefined;
      });
      
   }
  }
});