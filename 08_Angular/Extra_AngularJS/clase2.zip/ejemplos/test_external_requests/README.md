Para ejecutar este ejercicio hay que usar un servidor (vale ejecutarlo bajo brackets). Las llamadas hechas con
$http, $request, $q no funcionarán de otra forma