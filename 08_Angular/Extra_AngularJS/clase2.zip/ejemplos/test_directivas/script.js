var app = angular.module("app", []);

app.directive("acTituloUnidireccional",[function() {
  
  var directiveDefinitionObject ={
    restrict:"E",
    replace : true,
    template:"<div><h1>{{texto}}</h1><button ng-click=\"texto='Texto cambiado desde dentro de la directiva'\">Cambiar valor de scope.texto de la directiva</button></div>",
    scope:{
      texto:"@"
    }
  }
  
  return directiveDefinitionObject;
}]);

app.directive("acTituloBidireccional",[function() {
  
  var directiveDefinitionObject ={
    restrict:"E",
    replace : true,
    template:"<div><h1>{{texto}}</h1><button ng-click=\"texto='Texto cambiado desde dentro de la directiva'\">Cambiar valor de scope.texto de la directiva</button></div>",
    scope:{
      texto:"="
    }
  }
  
  return directiveDefinitionObject;
}]);




app.controller("PruebaController", function($scope) {
  $scope.mensajeUnidireccional="Texto Unidireccional del controlador ";
  $scope.mensajeBidireccional="Texto Bidireccional del controlador "; 
  
  
  $scope.cambiarMensajeUnidireccional=function() {
    $scope.mensajeUnidireccional="Cambiado el texto Unidireccional del controlador ";
  }
  
  $scope.cambiarMensajeBidireccional=function() {
    $scope.mensajeBidireccional="Cambiado el texto Bidireccional del controlador"; 
  }
  
});