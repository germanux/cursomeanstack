var app = angular.module("app", []);

function RemoteResourceService($http, baseUrl) {
    this.baseUrl = baseUrl;
    
    this.setBaseUrl = function(baseUrl) {
        this.baseUrl = baseUrl;
    }
    
    this.get = function(fnOK, fnError) {
        $http({
            method: 'GET',
            url: baseUrl + '/datos.json'
        }).success(function(data, status, header, config) {
            fnOK(data);         
        }).error(function(data, status, headers, config) {
            fnError(data,status);
        });
    }
}

RemoteResourceService.$inject = ['$http', 'baseUrl'];


function RemoteResourceController($scope, remoteResourceService) {
    $scope.seguro = {
      nif: "",
      nombre: "",
      ape1: "",
      edad: undefined,
      sexo: "",
      casado: false,
      numHijos: undefined,
      embarazada: false,
      coberturas: {
        oftalmologia: false,
        dental: false,
        fecundacionInVitro: false
      },
      enfermedades: {
        corazon: false,
        estomacal: false,
        rinyones: false,
        alergia: false,
        nombreAlergia: ""
      },
      fechaCreacion: new Date()
    }
    
    remoteResourceService.get(
        function(seguro) {
            $scope.seguro = seguro;
        }, 
        function(data, status) {
            alert("Ha fallado la petición. Estado HTTP:" + status);
        });
}

RemoteResourceController.$inject = ['$scope', 'remoteResourceService'];


app.constant("baseUrl", ".");

app.service('remoteResourceService', RemoteResourceService);

app.controller("SeguroController", RemoteResourceController);
