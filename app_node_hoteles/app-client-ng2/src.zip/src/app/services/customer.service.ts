import {Customer} from "../models/customer.model";
import {Injectable} from "@angular/core";
import {
    Http,  Headers as AngularHeaders,
Request, RequestOptions, RequestMethod as RequestMethods,
Response, 
URLSearchParams
} from "@angular/http";
import {Observable} from "rxjs/Observable";
import {RESTClient, GET, PUT, POST, DELETE, BaseUrl, Headers, DefaultHeaders, Path, Body, Query} from "angular2-rest";

@Injectable()
@BaseUrl('http://localhost:3000/api/customers/name/')
@DefaultHeaders({
    'Accept': 'application/json',
    'Content-Type': 'application/json'
})
export class CustomerService extends RESTClient {
    public enviar(customer: Customer) {
        alert(customer.name);
    } 

    @GET("customers/")
    public getCustomers( @Query("sort") sort?: string): Observable<Customer> { return null; };

    @GET("customers/{id}")
    public getCustomerById( @Path("id") id: string): Observable<Customer> { return null; };
    @GET("customers/name/{name}")
    public getCustomerByName( @Path("name") name: string): Observable<Customer> { return null; };

    @POST("customers")
    public postCustomer( @Body customer: Customer): Observable<Customer> { return null; };

    @PUT("customers/{id}")
    public putCustomerById( @Path("id") id: string, @Body todo: Customer): Observable<Customer> { return null; };

    @DELETE("customers/{id}")
    public deleteCustomerById( @Path("id") id: string): Observable<Customer> { return null; };
}